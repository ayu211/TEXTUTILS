import './App.css';
import About from './components/About';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
import React, { useState } from 'react';
import Alert from './components/Alert';

import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

function App() {
  const[mode, setMode] = useState("light");
  // const[modetext, setModeText] = useState("Enable Dark Mode");
  const[alert, setAlert] = useState(null);
  // const[dark,setDark] = useState("dark");

  const removeclass = ()=>{
    document.body.classList.remove('bg-primary');
    document.body.classList.remove('bg-light');
    document.body.classList.remove('bg-dark');
    document.body.classList.remove('bg-danger');
    document.body.classList.remove('bg-success');
    document.body.classList.remove('bg-warning');
  }
  
  const darkclick = ()=>{
    removeclass();
    setMode("dark");
    document.body.style.backgroundColor= 'black';
  }
  const yellowclick = ()=>{
    removeclass();
    setMode("warning");
    document.body.style.backgroundColor= '#604e16';
  }
  const redclick = ()=>{
    removeclass();
    setMode("danger");
    document.body.style.backgroundColor= '#701a1a';
  }
  const whiteclick = ()=>{
    removeclass();
    setMode("light");
    document.body.style.backgroundColor= 'white';
  }
  const greenclick = ()=>{
    removeclass();
    setMode("success");
    document.body.style.backgroundColor= '#0b3421';
  }
  const blueclick = ()=>{
    removeclass();
    setMode("primary");
    document.body.style.backgroundColor= '#112d56';
  }
  
  const removeactive=()=>{
    document.body.classList.remove('active');
  }
  const[active,setActive] = useState("");
  const[active2,setActive2] = useState("");
  
  const activepage1 = ()=>{
  removeactive();
  setActive("active");
  }
  const activepage2 = ()=>{
    removeactive();
    setActive2("active");
    }

  const showAlert = (message,type)=>{
    setAlert({
      msg: message,
      type: type
    })
    setTimeout(() => {
      setAlert(null);
    }, 1000);
  }


  // const toggleMode = ()=>{
  //   if(mode === 'light'){
  //     setMode("dark");
  //     document.body.style.backgroundColor = "black";
  //     setModeText('Disable Dark Mode');
  //     showAlert("Dark mode enabled", "success")
  //   }else{
  //     setMode("light");
  //     document.body.style.backgroundColor = "white";
  //     setModeText('Enable Dark Mode');
  //     showAlert("Dark mode disabled", "success")
  //   }
    

  // }

  return (
      <>
      <BrowserRouter>
          <Navbar title="TextUtils" about="About TextUtils" active2={active2} mode={mode} activepage1={activepage1} activepage2={activepage2} active={active} darkclick={darkclick} whiteclick={whiteclick} redclick={redclick} greenclick={greenclick} yellowclick={yellowclick} blueclick={blueclick} />
          <Alert alert= {alert}/>
            <div className="container my-3">
              <Routes>
                  <Route path= "/about" element={<About mode={mode}/>}></Route>
                  <Route path="/" element={<TextForm showAlert={showAlert} heading="Enter the text to analyze below" mode={mode}/>}></Route>
              </Routes>
            </div>
      </BrowserRouter>
      </>
    );
}

export default App;
