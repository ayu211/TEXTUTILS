import React, { useState } from 'react'

export default function TextForm(props) {
    // hook --> usestate
    
    const Uppercase = ()=>{
        // console.log("Clicked");
        let newText = text.toUpperCase();
        setText(newText);
        props.showAlert("Converted to Uppercase", "success");
    };
    const handlechange = (event)=>{
        // console.log("type");
        setText(event.target.value);
    };
    const Lowercase = ()=>{
        // console.log("btn2 clicked");
        let newText = text.toLowerCase();
        setText(newText);
        props.showAlert("Converted to Lowercase", "success");
    }
    const[text, setText] = useState("");
    const Cleartext = ()=>{
        setText("");
        props.showAlert("Cleared", "success");
    }
    const Copytext = ()=>{
        var mytext = document.getElementById("myBox");
        mytext.select();
        navigator.clipboard.writeText(mytext.value);
        props.showAlert("Text Copied", "success");
    }
  return (
    <>
        <div className='container my-3' style={{color:props.mode === 'light'?'black':'white'}}>
            <h1>{props.heading}</h1>
            <div className="mb-3">
                <textarea value={text} className={`form-control bg-${props.mode}`} id="myBox" rows="8" style={{color:props.mode === 'dark'?'white':'black'}} onChange={handlechange}></textarea>
            </div>
            <button className={`btn btn-${props.mode} mx-1`} disabled={text.length === 0} onClick={Uppercase}>Convert to UpperCase</button>
            <button className={`btn btn-${props.mode} mx-1`} disabled={text.length === 0} onClick={Lowercase}>Convert to LowerCase</button>
            <button className={`btn btn-${props.mode} mx-1`} disabled={text.length === 0} onClick={Cleartext}>Clear Text</button>
            <button className={`btn btn-${props.mode} mx-1`} disabled={text.length === 0} onClick={Copytext}>Copy Text</button>
        </div>
        <div className="container my-3" style={{color:props.mode === 'light'?'black':'white'}}>
            <h2>Your Text Summary</h2>
            <p>{text.split(" ").filter((element)=>{return element.length!==0}).length} words and {text.length} characters</p>
            <p>{0.008 * text.split(" ").filter((element)=>{return element.length!==0}).length} Minutes to read</p>
            <h2>Preview</h2>
            <p>{text}</p>
        </div>
    </>
  )
}
