import React from 'react'

export default function Alert(props) {
    const capitalize = (word)=>{
        const x = word.toLowerCase();
        return word.charAt(0).toUpperCase() + x.slice(1);
    }
    

  return (
    <div style={{height:'50px'}}>
       { props.alert && <div className={`alert alert-${props.alert.type} d-flex align-items-center`} role="alert">
            <strong>{capitalize(props.alert.type)}</strong>: {props.alert.msg}
        </div>}
    </div>
  );
};
